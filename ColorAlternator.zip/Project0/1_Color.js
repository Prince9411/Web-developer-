 const button = document.querySelectorAll(".button")
 const body=document.querySelector('body')
 button.forEach( function (button) {
  //  console.log(button);
    
 button.addEventListener('click',function(e){
    // console.log("e", e);
    
    // console.log(e.target);
    
 if(e.target.id==='Grey')
 {
    body.style.backgroundColor= "grey"
 }
 if(e.target.id=== 'Yellow')
 {
    body.style.backgroundColor ='yellow'
 }
 if(e.target.id=== 'Orange')
    {
       body.style.backgroundColor ='orange'
    } 
    if(e.target.id=== 'White')
        {
           body.style.backgroundColor ='white'
        } 
        if(e.target.id=== 'Blue')
            {
               body.style.backgroundColor ='blue'
            }
    })
 })


 