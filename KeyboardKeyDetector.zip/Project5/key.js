let insert = document.getElementById('insert')
let key = document.getElementById('key')
window.addEventListener("keydown", (e) => {
    insert.innerHTML = `
   <table border=1px> 
   <tr> 
   <th>Key</th>
    <th>Code</th>
        <th>Keycode</th>
   </tr>
   <tr>
   <td>${e.key}</td>
   <td>${e.code}</td>
   <td>${e.keyCode}</td>
   </tr>
   </table>
   </div>
   `
    
})