clock= document.querySelector('#clock')

// let date =new Date()
// console.log(date.toLocaleTimeString());

setInterval(function(){
    let date =new Date()
//console.log(date.toLocaleTimeString());
clock.innerHTML = date.toLocaleTimeString()  //date.toLocaleString()
}, 1000)