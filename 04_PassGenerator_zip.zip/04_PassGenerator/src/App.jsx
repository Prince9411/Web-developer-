import { useState, useCallback,useEffect,useRef } from 'react';
import './App.css';

function App() {
  const [length, setLength] = useState(8);
  const [numberAllow, setNumberAllow] = useState(false);
  const [charAllow, setCharAllow] = useState(false);
  const [password, setPassword] = useState('');

  //USeRef hook
  const passwordRef = useRef(null)

  const passwordGenerator = useCallback(() => {
    let pass = ""
    let str= "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    if(numberAllow) str += '0123456789'
    if(charAllow) str += '!@#$%^&*()}{~` '
    for (let i = 1; i <= length; i++){
      
let char = Math.floor(Math.random() *str.length )     
pass += str.charAt(char)
    }
    setPassword(pass)
  }, [length, numberAllow, charAllow ]); 
  useEffect(() =>{
    passwordGenerator()
  }, [length,numberAllow,charAllow])
  const copyPassword =useCallback(() => {
    window.navigator.clipboard.writeText(password)
  },[password])  //dependency
  return (
    <>
      {/* <h1 className="text-4xl text-center text-white">Password Generator</h1> */}
      <div className='w-full max-w-md mx-auto shadow-md text-orange-500 bg-gray-700'>
        <div> <input type='text' value={password} placeholder='Your password' readOnly ref = {passwordRef}></input>
<button onClick={copyPassword}>Copy</button>
        </div>
        <div>
          <input
          type='range'
          min={1}
          max={100}
          value={length}
            className="cursor-pointer"
            onChange={(e) =>{setLength(e.target.value)}}
          ></input>
          <label>Length:{length}</label>
        </div>
        <div > 
          <input
          type='checkbox'
          defaultChecked={numberAllow}
          id='numberInput'
          onChange={() => {
            setNumberAllow((prev) => !prev)
          }}></input>
          <label >Numbers</label>
        </div>
        <input 
        type='checkbox'
        defaultChecked = {charAllow}
        onChange={() => {
          setCharAllow((prev) => !prev )
        }}
        ></input>
        <label>Character</label>
        
        <div>

        </div>
      </div>
    </>
  );
}

export default App;
